
import React from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { 
  CheckCircle, 
  BarChart3, 
  Users, 
  FileText, 
  ArrowRight 
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const Index = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-navy text-white py-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
            <div className="space-y-6 animate-fade-in">
              <h1 className="text-4xl md:text-5xl font-bold leading-tight">
                Streamline Your <span className="text-teal">Admission</span> Process
              </h1>
              <p className="text-lg md:text-xl text-gray-300">
                Manage student applications, track enrollment progress, and make data-driven decisions with our comprehensive admission management system.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link to="/dashboard">
                  <Button className="bg-teal hover:bg-teal-dark text-white px-6">
                    Go to Dashboard
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
                <Link to="/applications">
                  <Button variant="outline" className="text-white border-white hover:bg-navy-light">
                    View Applications
                  </Button>
                </Link>
              </div>
            </div>
            <div className="flex justify-center">
              <img 
                src="https://i.imgur.com/1THyfXF.png" 
                alt="Admission Management System" 
                className="max-w-full h-auto rounded-lg shadow-lg" 
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 md:px-6">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-navy mb-4">Key Features</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Our admission management system offers everything you need to streamline your institution's enrollment process.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-t-4 border-t-teal">
              <CardContent className="pt-6">
                <div className="bg-teal-light/10 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                  <FileText className="h-6 w-6 text-teal" />
                </div>
                <h3 className="text-xl font-bold mb-2 text-navy">Application Management</h3>
                <p className="text-gray-600">
                  Easily track and process student applications from submission to decision with our intuitive interface.
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-t-4 border-t-teal">
              <CardContent className="pt-6">
                <div className="bg-teal-light/10 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                  <Users className="h-6 w-6 text-teal" />
                </div>
                <h3 className="text-xl font-bold mb-2 text-navy">Student Database</h3>
                <p className="text-gray-600">
                  Maintain comprehensive profiles for each applicant with all relevant information in one secure location.
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-t-4 border-t-teal">
              <CardContent className="pt-6">
                <div className="bg-teal-light/10 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                  <BarChart3 className="h-6 w-6 text-teal" />
                </div>
                <h3 className="text-xl font-bold mb-2 text-navy">Advanced Analytics</h3>
                <p className="text-gray-600">
                  Generate insightful reports and visualizations to make data-driven decisions about your admission process.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="bg-gray-50 py-16 px-4 md:px-6">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-navy mb-4">Why Choose Our System</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Our admission management system is designed to solve the unique challenges faced by educational institutions.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0">
                <CheckCircle className="h-6 w-6 text-teal" />
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">Improved Efficiency</h3>
                <p className="text-gray-600">
                  Reduce administrative overhead and speed up application processing with automated workflows.
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0">
                <CheckCircle className="h-6 w-6 text-teal" />
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">Better Decision Making</h3>
                <p className="text-gray-600">
                  Use comprehensive analytics to identify trends and make informed admission decisions.
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0">
                <CheckCircle className="h-6 w-6 text-teal" />
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">Enhanced Communication</h3>
                <p className="text-gray-600">
                  Keep applicants informed throughout the admission process with automated status updates.
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0">
                <CheckCircle className="h-6 w-6 text-teal" />
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">Centralized Information</h3>
                <p className="text-gray-600">
                  Store all applicant data, documents, and communication history in one secure platform.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 px-4 md:px-6 text-center">
        <div className="container mx-auto max-w-3xl">
          <h2 className="text-3xl font-bold text-navy mb-4">Ready to Transform Your Admission Process?</h2>
          <p className="text-lg text-gray-600 mb-8">
            Get started with our comprehensive admission management system today and see the difference it makes for your institution.
          </p>
          <Link to="/dashboard">
            <Button className="bg-teal hover:bg-teal-dark text-white px-8 py-6 text-lg">
              Get Started Now
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Index;
