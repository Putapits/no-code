
import React, { useState } from 'react';
import { 
  mockApplications, 
  mockPrograms
} from '@/data/mockData';
import ApplicationsTable from '@/components/dashboard/ApplicationsTable';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { UserPlus, FileText, Search, Filter } from 'lucide-react';

const Applications = () => {
  const [filter, setFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  const filteredApplications = mockApplications.filter(app => {
    if (filter !== 'all' && app.status !== filter) {
      return false;
    }
    if (searchQuery) {
      // Simple search - could be enhanced to search across related entities
      return app.id.toLowerCase().includes(searchQuery.toLowerCase());
    }
    return true;
  });

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <h1 className="text-3xl font-bold text-navy">Applications</h1>
        <div className="flex gap-2">
          <Button className="bg-teal hover:bg-teal-dark">
            <FileText className="h-4 w-4 mr-2" />
            New Application
          </Button>
        </div>
      </div>
      
      <div className="flex flex-col sm:flex-row gap-4 items-end">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search applications..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-full sm:w-[180px]">
              <SelectValue placeholder="Filter by Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Applications</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="reviewing">Reviewing</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="rounded-md bg-white">
        <ApplicationsTable 
          applications={filteredApplications}
          showStudent={true}
          showProgram={true}
        />
      </div>
    </div>
  );
};

export default Applications;
