
import React from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  mockPrograms, 
  mockApplications, 
  getApplicationStatistics, 
  getProgramStatistics 
} from '@/data/mockData';
import { BarChart3, PieChart, LineChart, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Reports = () => {
  const appStats = getApplicationStatistics();
  const programStats = getProgramStatistics();
  
  // Get applications by month for the current year
  const applicationsByMonth = Array(12).fill(0);
  const currentYear = new Date().getFullYear();
  
  mockApplications.forEach(app => {
    const date = new Date(app.submissionDate);
    if (date.getFullYear() === currentYear) {
      applicationsByMonth[date.getMonth()]++;
    }
  });
  
  // Calculate program distribution percentages
  const programDistribution = mockPrograms.map(program => ({
    name: program.name,
    applications: mockApplications.filter(app => app.programId === program.id).length,
    percentage: (mockApplications.filter(app => app.programId === program.id).length / mockApplications.length) * 100
  }));

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-navy">Reports & Analytics</h1>
        <Button variant="outline">
          <Download className="h-4 w-4 mr-2" />
          Export Data
        </Button>
      </div>
      
      <Tabs defaultValue="overview" className="w-full">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="applications">Applications</TabsTrigger>
          <TabsTrigger value="programs">Programs</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-6 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Applications</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{appStats.total}</div>
                <div className="text-xs text-muted-foreground mt-1">
                  {currentYear} applications
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Approval Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{appStats.approvalRate.toFixed(1)}%</div>
                <Progress value={appStats.approvalRate} className="h-2 mt-2" />
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Program Occupancy</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{programStats.occupancyRate.toFixed(1)}%</div>
                <Progress value={programStats.occupancyRate} className="h-2 mt-2" />
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Programs Near Capacity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{programStats.programsNearCapacity}</div>
                <div className="text-xs text-muted-foreground mt-1">
                  Out of {programStats.programCount} total programs
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Application Trends</CardTitle>
                <CardDescription>
                  Monthly applications for {currentYear}
                </CardDescription>
              </CardHeader>
              <CardContent className="h-80 flex items-center justify-center">
                <LineChart className="h-16 w-16 text-muted-foreground" />
                <div className="ml-4 text-muted-foreground">
                  Application trend visualization would appear here
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Application Status Distribution</CardTitle>
                <CardDescription>
                  Breakdown of application statuses
                </CardDescription>
              </CardHeader>
              <CardContent className="h-80 flex items-center justify-center">
                <PieChart className="h-16 w-16 text-muted-foreground" />
                <div className="ml-4 text-muted-foreground">
                  Status distribution visualization would appear here
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="applications" className="space-y-6 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>Application Status Breakdown</CardTitle>
              <CardDescription>
                Detailed view of application statuses
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-100">
                  <h3 className="text-yellow-800 font-medium">Pending</h3>
                  <div className="text-2xl font-bold mt-1">{appStats.pending}</div>
                  <div className="text-xs text-yellow-700 mt-1">
                    {((appStats.pending / appStats.total) * 100).toFixed(1)}% of total
                  </div>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
                  <h3 className="text-blue-800 font-medium">Reviewing</h3>
                  <div className="text-2xl font-bold mt-1">{appStats.reviewing}</div>
                  <div className="text-xs text-blue-700 mt-1">
                    {((appStats.reviewing / appStats.total) * 100).toFixed(1)}% of total
                  </div>
                </div>
                <div className="bg-green-50 p-4 rounded-lg border border-green-100">
                  <h3 className="text-green-800 font-medium">Approved</h3>
                  <div className="text-2xl font-bold mt-1">{appStats.approved}</div>
                  <div className="text-xs text-green-700 mt-1">
                    {((appStats.approved / appStats.total) * 100).toFixed(1)}% of total
                  </div>
                </div>
                <div className="bg-red-50 p-4 rounded-lg border border-red-100">
                  <h3 className="text-red-800 font-medium">Rejected</h3>
                  <div className="text-2xl font-bold mt-1">{appStats.rejected}</div>
                  <div className="text-xs text-red-700 mt-1">
                    {((appStats.rejected / appStats.total) * 100).toFixed(1)}% of total
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Monthly Application Volume</CardTitle>
              <CardDescription>
                Applications received per month in {currentYear}
              </CardDescription>
            </CardHeader>
            <CardContent className="h-80 flex items-center justify-center">
              <BarChart3 className="h-16 w-16 text-muted-foreground" />
              <div className="ml-4 text-muted-foreground">
                Monthly application volume visualization would appear here
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="programs" className="space-y-6 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>Program Popularity</CardTitle>
              <CardDescription>
                Applications distribution across programs
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {programDistribution.map((program) => (
                  <div key={program.name} className="space-y-2">
                    <div className="flex justify-between">
                      <span className="font-medium">{program.name}</span>
                      <span>{program.applications} applications</span>
                    </div>
                    <Progress value={program.percentage} className="h-2" />
                    <div className="text-xs text-muted-foreground">
                      {program.percentage.toFixed(1)}% of total applications
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Program Enrollment Status</CardTitle>
              <CardDescription>
                Current enrollment numbers versus capacity
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {mockPrograms.map((program) => {
                  const percentage = (program.enrolled / program.capacity) * 100;
                  let statusColor = "bg-green-500";
                  
                  if (percentage >= 90) {
                    statusColor = "bg-red-500";
                  } else if (percentage >= 75) {
                    statusColor = "bg-yellow-500";
                  }
                  
                  return (
                    <div key={program.id} className="space-y-2">
                      <div className="flex justify-between">
                        <span className="font-medium">{program.name}</span>
                        <span>{program.enrolled} / {program.capacity}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div 
                          className={`h-2.5 rounded-full ${statusColor}`}
                          style={{ width: `${percentage}%` }}
                        ></div>
                      </div>
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{percentage.toFixed(1)}% filled</span>
                        <span>{program.capacity - program.enrolled} spots remaining</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Reports;
