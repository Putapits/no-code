
export interface Student {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  dob: string;
  address: string;
  photo?: string;
}

export interface Application {
  id: string;
  studentId: string;
  programId: string;
  status: 'pending' | 'reviewing' | 'approved' | 'rejected';
  submissionDate: string;
  documents: Document[];
  notes?: string;
  reviewedBy?: string;
  reviewDate?: string;
}

export interface Document {
  id: string;
  name: string;
  type: string;
  uploadDate: string;
  verified: boolean;
}

export interface Program {
  id: string;
  name: string;
  description: string;
  department: string;
  duration: string;
  fee: number;
  startDate: string;
  capacity: number;
  enrolled: number;
}

export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  role: 'admin' | 'staff' | 'reviewer';
  department?: string;
}

// Mock data
export const mockStudents: Student[] = [
  {
    id: "STU001",
    firstName: "John",
    lastName: "Doe",
    email: "john.doe@example.com",
    phone: "123-456-7890",
    dob: "1998-05-15",
    address: "123 Main St, Anytown, AN 12345",
    photo: "https://i.pravatar.cc/150?img=1"
  },
  {
    id: "STU002",
    firstName: "Jane",
    lastName: "Smith",
    email: "jane.smith@example.com",
    phone: "123-456-7891",
    dob: "1997-07-22",
    address: "456 Oak Ave, Somecity, SC 67890",
    photo: "https://i.pravatar.cc/150?img=5"
  },
  {
    id: "STU003",
    firstName: "Michael",
    lastName: "Johnson",
    email: "michael.j@example.com",
    phone: "123-456-7892",
    dob: "1999-02-10",
    address: "789 Pine Rd, Otherville, OV 54321",
    photo: "https://i.pravatar.cc/150?img=3"
  },
  {
    id: "STU004",
    firstName: "Emily",
    lastName: "Williams",
    email: "emily.w@example.com",
    phone: "123-456-7893",
    dob: "2000-11-05",
    address: "321 Cedar Ln, Newtown, NT 13579",
    photo: "https://i.pravatar.cc/150?img=4"
  },
  {
    id: "STU005",
    firstName: "David",
    lastName: "Brown",
    email: "david.b@example.com",
    phone: "123-456-7894",
    dob: "1996-09-18",
    address: "654 Maple Dr, Oldcity, OC 97531",
    photo: "https://i.pravatar.cc/150?img=7"
  }
];

export const mockPrograms: Program[] = [
  {
    id: "PRG001",
    name: "Computer Science",
    description: "Bachelor of Science in Computer Science",
    department: "Engineering",
    duration: "4 years",
    fee: 12500,
    startDate: "2023-09-01",
    capacity: 100,
    enrolled: 78
  },
  {
    id: "PRG002",
    name: "Business Administration",
    description: "Bachelor of Business Administration",
    department: "Business",
    duration: "3 years",
    fee: 10000,
    startDate: "2023-09-01",
    capacity: 120,
    enrolled: 95
  },
  {
    id: "PRG003",
    name: "Graphic Design",
    description: "Bachelor of Arts in Graphic Design",
    department: "Arts",
    duration: "3 years",
    fee: 9500,
    startDate: "2023-09-01",
    capacity: 60,
    enrolled: 42
  },
  {
    id: "PRG004",
    name: "Mechanical Engineering",
    description: "Bachelor of Engineering in Mechanical Engineering",
    department: "Engineering",
    duration: "4 years",
    fee: 13000,
    startDate: "2023-09-01",
    capacity: 80,
    enrolled: 65
  },
  {
    id: "PRG005",
    name: "Psychology",
    description: "Bachelor of Science in Psychology",
    department: "Science",
    duration: "3 years",
    fee: 11000,
    startDate: "2023-09-01",
    capacity: 90,
    enrolled: 82
  }
];

export const mockApplications: Application[] = [
  {
    id: "APP001",
    studentId: "STU001",
    programId: "PRG001",
    status: "approved",
    submissionDate: "2023-03-15",
    documents: [
      {
        id: "DOC001",
        name: "Transcript",
        type: "PDF",
        uploadDate: "2023-03-15",
        verified: true
      },
      {
        id: "DOC002",
        name: "ID Proof",
        type: "JPG",
        uploadDate: "2023-03-15",
        verified: true
      }
    ],
    notes: "Strong academic background",
    reviewedBy: "USR002",
    reviewDate: "2023-04-01"
  },
  {
    id: "APP002",
    studentId: "STU002",
    programId: "PRG003",
    status: "reviewing",
    submissionDate: "2023-03-20",
    documents: [
      {
        id: "DOC003",
        name: "Transcript",
        type: "PDF",
        uploadDate: "2023-03-20",
        verified: true
      },
      {
        id: "DOC004",
        name: "Portfolio",
        type: "PDF",
        uploadDate: "2023-03-20",
        verified: false
      }
    ],
    notes: "Portfolio under review"
  },
  {
    id: "APP003",
    studentId: "STU003",
    programId: "PRG002",
    status: "pending",
    submissionDate: "2023-03-25",
    documents: [
      {
        id: "DOC005",
        name: "Transcript",
        type: "PDF",
        uploadDate: "2023-03-25",
        verified: false
      }
    ]
  },
  {
    id: "APP004",
    studentId: "STU004",
    programId: "PRG004",
    status: "rejected",
    submissionDate: "2023-03-10",
    documents: [
      {
        id: "DOC006",
        name: "Transcript",
        type: "PDF",
        uploadDate: "2023-03-10",
        verified: true
      },
      {
        id: "DOC007",
        name: "Recommendation Letter",
        type: "PDF",
        uploadDate: "2023-03-10",
        verified: true
      }
    ],
    notes: "Does not meet minimum requirements",
    reviewedBy: "USR001",
    reviewDate: "2023-03-30"
  },
  {
    id: "APP005",
    studentId: "STU005",
    programId: "PRG005",
    status: "approved",
    submissionDate: "2023-03-18",
    documents: [
      {
        id: "DOC008",
        name: "Transcript",
        type: "PDF",
        uploadDate: "2023-03-18",
        verified: true
      },
      {
        id: "DOC009",
        name: "ID Proof",
        type: "JPG",
        uploadDate: "2023-03-18",
        verified: true
      }
    ],
    reviewedBy: "USR003",
    reviewDate: "2023-04-05"
  }
];

export const mockUsers: User[] = [
  {
    id: "USR001",
    firstName: "Admin",
    lastName: "User",
    email: "admin@example.com",
    role: "admin"
  },
  {
    id: "USR002",
    firstName: "Staff",
    lastName: "Member",
    email: "staff@example.com",
    role: "staff",
    department: "Admissions"
  },
  {
    id: "USR003",
    firstName: "Review",
    lastName: "Person",
    email: "reviewer@example.com",
    role: "reviewer",
    department: "Engineering"
  }
];

// Helper functions to get data
export const getStudentById = (id: string): Student | undefined => {
  return mockStudents.find(student => student.id === id);
};

export const getProgramById = (id: string): Program | undefined => {
  return mockPrograms.find(program => program.id === id);
};

export const getApplicationsForStudent = (studentId: string): Application[] => {
  return mockApplications.filter(app => app.studentId === studentId);
};

export const getApplicationsForProgram = (programId: string): Application[] => {
  return mockApplications.filter(app => app.programId === programId);
};

export const getApplicationById = (id: string): Application | undefined => {
  return mockApplications.find(app => app.id === id);
};

// Statistics
export const getApplicationStatistics = () => {
  const total = mockApplications.length;
  const pending = mockApplications.filter(app => app.status === 'pending').length;
  const reviewing = mockApplications.filter(app => app.status === 'reviewing').length;
  const approved = mockApplications.filter(app => app.status === 'approved').length;
  const rejected = mockApplications.filter(app => app.status === 'rejected').length;
  
  return {
    total,
    pending,
    reviewing,
    approved,
    rejected,
    approvalRate: total > 0 ? (approved / total) * 100 : 0
  };
};

export const getProgramStatistics = () => {
  const totalCapacity = mockPrograms.reduce((sum, program) => sum + program.capacity, 0);
  const totalEnrolled = mockPrograms.reduce((sum, program) => sum + program.enrolled, 0);
  
  return {
    programCount: mockPrograms.length,
    totalCapacity,
    totalEnrolled,
    occupancyRate: totalCapacity > 0 ? (totalEnrolled / totalCapacity) * 100 : 0,
    programsNearCapacity: mockPrograms.filter(program => (program.enrolled / program.capacity) > 0.9).length
  };
};
