
import React from 'react';
import Navbar from './Navbar';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col bg-lightbg">
      <Navbar />
      <main className="flex-1 container mx-auto">
        {children}
      </main>
      <footer className="bg-navy text-white py-4 mt-auto">
        <div className="container mx-auto text-center text-sm">
          <p>&copy; {new Date().getFullYear()} StellarEnroll - Admission Management System</p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
