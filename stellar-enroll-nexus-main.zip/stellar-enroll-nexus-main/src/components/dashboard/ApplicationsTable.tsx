
import React from 'react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Application, 
  getStudentById, 
  getProgramById 
} from '@/data/mockData';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText } from 'lucide-react';
import { Link } from 'react-router-dom';

interface ApplicationsTableProps {
  applications: Application[];
  showStudent?: boolean;
  showProgram?: boolean;
}

const ApplicationsTable: React.FC<ApplicationsTableProps> = ({
  applications,
  showStudent = false,
  showProgram = false,
}) => {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Pending</Badge>;
      case 'reviewing':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 hover:bg-blue-100">Reviewing</Badge>;
      case 'approved':
        return <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">Approved</Badge>;
      case 'rejected':
        return <Badge variant="outline" className="bg-red-100 text-red-800 hover:bg-red-100">Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>ID</TableHead>
            {showStudent && <TableHead>Student</TableHead>}
            {showProgram && <TableHead>Program</TableHead>}
            <TableHead>Submission Date</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {applications.length === 0 ? (
            <TableRow>
              <TableCell colSpan={showStudent && showProgram ? 6 : (showStudent || showProgram ? 5 : 4)} className="text-center py-6 text-muted-foreground">
                No applications found
              </TableCell>
            </TableRow>
          ) : (
            applications.map((application) => {
              const student = showStudent ? getStudentById(application.studentId) : null;
              const program = showProgram ? getProgramById(application.programId) : null;
              
              return (
                <TableRow key={application.id}>
                  <TableCell className="font-medium">{application.id}</TableCell>
                  {showStudent && (
                    <TableCell>
                      {student ? `${student.firstName} ${student.lastName}` : 'Unknown'}
                    </TableCell>
                  )}
                  {showProgram && (
                    <TableCell>
                      {program ? program.name : 'Unknown'}
                    </TableCell>
                  )}
                  <TableCell>{new Date(application.submissionDate).toLocaleDateString()}</TableCell>
                  <TableCell>{getStatusBadge(application.status)}</TableCell>
                  <TableCell className="text-right">
                    <Link to={`/applications/${application.id}`}>
                      <Button variant="ghost" size="sm">
                        <FileText className="h-4 w-4 mr-1" />
                        View
                      </Button>
                    </Link>
                  </TableCell>
                </TableRow>
              );
            })
          )}
        </TableBody>
      </Table>
    </div>
  );
};

export default ApplicationsTable;
